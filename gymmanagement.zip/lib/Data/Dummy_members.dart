import 'package:gymmanagement/Models/member_model.dart';

List<Member> dummyMembers = [
  Member(
    name: "Rahul Sharma",
    mobile: "9876543210",
    plan: "Monthly",
    status: "Active",
    joinDate: "01 Jan 2024",
    expiryDate: "01 Feb 2024",
    attendance: 18,
  ),
  Member(
    name: "Amit Verma",
    mobile: "9123456789",
    plan: "Yearly",
    status: "Expired",
    joinDate: "01 Jan 2023",
    expiryDate: "01 Jan 2024",
    attendance: 210,
  ),
];
